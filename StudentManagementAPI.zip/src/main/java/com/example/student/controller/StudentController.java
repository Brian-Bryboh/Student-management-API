package com.example.student.controller;

import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/students")
public class StudentController {

    private Map<Integer, Student> students = new HashMap<>();
    private int idCounter = 1;

    @GetMapping
    public Collection<Student> getAllStudents() {
        return students.values();
    }

    @PostMapping
    public String addStudent(@RequestBody Student student) {
        student.setId(idCounter++);
        students.put(student.getId(), student);
        return "Student added with ID: " + student.getId();
    }

    @PutMapping("/{id}")
    public String updateStudent(@PathVariable int id, @RequestBody Student updatedStudent) {
        if (students.containsKey(id)) {
            updatedStudent.setId(id);
            students.put(id, updatedStudent);
            return "Student with ID " + id + " updated.";
        }
        return "Student not found.";
    }

    @DeleteMapping("/{id}")
    public String deleteStudent(@PathVariable int id) {
        if (students.remove(id) != null) {
            return "Student with ID " + id + " deleted.";
        }
        return "Student not found.";
    }

    static class Student {
        private int id;
        private String name;
        private String course;

        // Getters and setters
        public int getId() { return id; }
        public void setId(int id) { this.id = id; }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

        public String getCourse() { return course; }
        public void setCourse(String course) { this.course = course; }
    }
}
