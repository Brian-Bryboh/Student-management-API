# Student Management REST API

This is a simple Spring Boot REST API to manage students using:

- @GetMapping – View all students
- @PostMapping – Add a new student
- @PutMapping – Update an existing student
- @DeleteMapping – Delete a student

## How to Run

1. Add Spring Web dependency in your pom.xml.
2. Place StudentController.java in the right package.
3. Create a Spring Boot main class.
4. Run the application.
5. Test endpoints using Postman or curl.

## Example Endpoints

- GET /students
- POST /students  (JSON body: { "name": "John", "course": "Math" })
- PUT /students/{id} (update name or course)
- DELETE /students/{id}
